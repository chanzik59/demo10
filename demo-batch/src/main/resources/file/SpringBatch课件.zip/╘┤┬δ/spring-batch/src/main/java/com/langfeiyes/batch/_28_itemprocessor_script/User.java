package com.langfeiyes.batch._28_itemprocessor_script;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@Getter
@Setter
@ToString
public class User {
    private Long id;
    private String name;
    private int age;
}